import os
import re
from setuptools import setup, find_packages
from io import open


with open('README.md', 'r', encoding='utf-8') as fp:
    readme = fp.read()

setup(
    name='cloudscrapersafe',
    author='devcodesourcehub',
    author_email='devcode@v3b.in',
    version="3.1.2",
    packages=find_packages(exclude=['tests*']),
    description='A Python module to bypass Cloudflare\'s anti-bot page.',
    long_description=readme,
    long_description_content_type='text/markdown',
    url='https://github.com/devcodesourcehub',
    keywords=[
       "scraping"
    ],
    include_package_data=True,
    package_data={
        "cloudscrapersafe": ["user_agent/browsers.json"]
    },
    install_requires=[
        'requests >= 2.9.2',
        'requests_toolbelt >= 0.9.1',
        'pyparsing >= 2.4.7',
        'pyjwt >= 2.10.1'
    ],
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Software Development :: Libraries :: Application Frameworks',
        'Topic :: Software Development :: Libraries :: Python Modules'
    ]
)
